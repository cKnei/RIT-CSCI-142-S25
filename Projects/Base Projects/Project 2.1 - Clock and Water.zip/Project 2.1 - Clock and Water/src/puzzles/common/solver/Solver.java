package puzzles.common.solver;

public class Solver {
    // TODO
}
