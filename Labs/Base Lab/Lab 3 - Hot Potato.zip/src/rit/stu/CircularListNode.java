package rit.stu;

import rit.cs.CircularList;

public class CircularListNode<E> implements CircularList<E> {
    // TODO - From problem solving.  Add the necessary private state to represent the head, cursor and size

    /**
     * Initialize the list to be empty.  This means the head and cursor are both null
     * and the size is 0.
     */
    public CircularListNode() {
        // TODO
    }

    @Override
    public void append(E element) {
        // TODO
    }

    @Override
    public int size() {
        // TODO
        return 0;
    }

    @Override
    public boolean valid() {
        // TODO
        return false;
    }

    @Override
    public void reset() {
        // TODO
    }

    @Override
    public void forward() {
        // TODO
    }

    @Override
    public void backward() {
        // TODO
    }

    @Override
    public E get() {
        // TODO
        return null;
    }

    @Override
    public E removeForward() {
        // TODO
        return null;
    }

    @Override
    public E removeBackward() {
        // TODO
        return null;
    }

    @Override
    public String toString() {
        // TODO:  Use System.lineSeparator() instead of "\n" when appending a newline!!!!
        return null;
    }
}
