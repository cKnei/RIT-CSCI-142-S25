import java.util.*;

/**
 * Class representing a node in a graph - to be written.
 * The node contains data of the given generic type. Neighbors are
 * stored internally in a collection.
 * Initially left empty to be implemented by students.
 *
 * @author RIT CS
 * @author <<YOUR NAME HERE>>
 */
public class Node<D> {
    // TODO instance variables
    
    // TODO constructor

    // TODO accessors

    // TODO function to add a neighbor
}
