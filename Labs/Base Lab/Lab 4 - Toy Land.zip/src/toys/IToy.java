package toys;

public interface IToy {
}
