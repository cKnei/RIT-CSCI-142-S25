The JUnit test classes for the toys are initially
stored in the temp directory which is excluded.

As you develop each new toy you will move its JUnit
from the excluded temp package into this package.